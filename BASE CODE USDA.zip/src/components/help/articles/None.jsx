import React, { Component } from 'react'
import Article from '../Article'

// F41, F11-13

export default class None extends Component {
  render() {
    return (
      <Article />
    )
  }
}
